const Brand = () => {
  return <div>Enter Brand</div>;
};

export default Brand;
